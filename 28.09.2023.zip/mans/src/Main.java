public class Main {
    public static void main(String[] args) {
        char klass = 'G';
        System.out.println("klass");
        int model = 89;
        System.out.println(model);
        byte kategory = 4;
        System.out.println(kategory);
        short batteryH = 56;
        System.out.println("batteryH");
        float kmh = 4.7333436F;
        System.out.println("kmh");
        double kwh = 4.355453532;
        System.out.println(kwh);
        long masse = 12121;
        System.out.println(masse);

        /*Пример: 345
Вывод в консоль: Число 345 -> 3, 4, 5
Другой пример: 987
Вывод в консоль: Число 987 -> 9, 8, 7
         */

        int nr1 = 345;
        int n1 = nr1 / 100;
        int n2 = nr1 % 100 / 10;
        int n3 = nr1 % 10;
        System.out.println( "Число " + nr1 + " -> " + n1 + ", " + n2 + ", " + n3 );

        int nr3 = 987;
        int v1 = nr3 / 100;
        int v2 = nr3 % 100 / 10;
        int v3 = nr3 % 10;
        System.out.println( "Число " + nr3 + " -> " + v1 + ", " + v2 + ", " + v3 );
    }

}